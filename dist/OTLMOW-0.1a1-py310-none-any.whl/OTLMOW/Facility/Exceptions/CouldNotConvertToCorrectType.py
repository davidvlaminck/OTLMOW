﻿class CouldNotConvertToCorrectType(Exception):
    pass