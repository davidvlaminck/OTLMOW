class GeldigeRelatie:
    def __init__(self, bron: str, doel: str, relatie: str):
        self.relatie = relatie
        self.doel = doel
        self.bron = bron
