class Datatypes:
    pass