﻿class KwantWrd:
    eenheid = None