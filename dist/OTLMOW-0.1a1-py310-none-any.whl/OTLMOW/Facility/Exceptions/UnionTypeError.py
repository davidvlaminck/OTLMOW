﻿class UnionTypeError(ValueError):
    pass