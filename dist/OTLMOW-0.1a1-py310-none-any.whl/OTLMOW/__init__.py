"""The MOW OTL implementation in Python"""

__version__ = '0.1a1'