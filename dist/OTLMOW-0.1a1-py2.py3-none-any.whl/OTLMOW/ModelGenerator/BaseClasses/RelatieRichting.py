from enum import Enum


class RelatieRichting(Enum):
    BRON_DOEL = 1
    DOEL_BRON = 2
    BEIDE = 3