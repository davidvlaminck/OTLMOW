# coding=utf-8
from OTLMOW.OTLModel.BaseClasses.OTLAttribuut import OTLAttribuut
from OTLMOW.OTLModel.Classes.SoortenrijkSchraalGraslandGraslandfase5 import SoortenrijkSchraalGraslandGraslandfase5


# Generated with OTLClassCreator. To modify: extend, do not edit
class HeischraalGrasland(SoortenrijkSchraalGraslandGraslandfase5):
    """G5d - blauwe knoop, blauwe zegge, bleeksporig
bosviooltje, bleke zegge, borstelgras, dicht
havikskruid, echte guldenroede, fijn
schapengras, fraai hertshooi, gelobde
maanvaren, gevlekte orchis, heidekartelblad,
hondsviooltje, kleine tijm, klokjesgentiaan,
knollathyrus, kruipganzerik, liggend walstro,
liggende vleugeltjesbloem, mannetjesereprijs,
spits havikskruid, stijf havikskruid, stijve
ogentroost, tandjesgras, tormentil, trekrus,
tweenervige zegge, veelbloemige veldbies,
zaagblad, klokjesgentiaan, heidekartelblad,
welriekende nachtorchis."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeischraalGrasland'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
